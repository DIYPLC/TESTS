#!/usr/bin/python3
# -*- coding: utf-8 -*-

import socket  # for TCP client
import struct  # for MODBUS protocol
import time
def modbus_tcp_client_read_holding_register_uint16(ip_address='127.0.0.1', tcp_port=502, modbus_address=1, register_address=0) -> int:
    if True:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #timeout_seconds = 1.0
        #client_socket.settimeout(timeout_seconds)
        client_socket.connect((ip_address, tcp_port))
        tx_transaction_id = 1
        tx_protocol_id = 0
        tx_message_length = 6
        tx_modbus_address = modbus_address
        tx_modbus_function = 3
        tx_register_address = register_address
        tx_register_count = 1
        tx_adu = struct.pack(">HHHBBHH", tx_transaction_id, tx_protocol_id, tx_message_length,
                             tx_modbus_address, tx_modbus_function, tx_register_address, tx_register_count)
        client_socket.send(tx_adu)
        print("tx_adu", tx_adu)
        rx_adu = client_socket.recv(1500)
        print("rx_adu", rx_adu)
        (rx_transaction_id, rx_protocol_id, rx_message_length, rx_modbus_address, rx_modbus_function,
         rx_byte_count, rx_register_value) = struct.unpack(">HHHBBBH", rx_adu)
        client_socket.close()
        del client_socket
    return rx_register_value



if __name__ == "__main__":
    while True:
        print("modbus_tcp_client_read_holding_register_uint16()")
        mw0 = modbus_tcp_client_read_holding_register_uint16(ip_address='192.168.13.127', tcp_port=502, modbus_address=1, register_address=0)
        print("receive mw0 = ", mw0)
        time.sleep(1)


# @COPYLEFT ALL WRONGS RESERVED :)
# Author: VA
# Contacts: DIY.PLC.314@gmail.com
# Date start LIB_PLC: 2014
# License: GNU GPL-2.0-or-later
# https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# https://www.youtube.com/watch?v=n1F_MfLRlX0
# https://www.youtube.com/@DIY_PLC
# https://github.com/DIYPLC/LIB_PLC
# https://oshwlab.com/diy.plc.314/PLC_HW1_SW1
# https://3dtoday.ru/3d-models/mechanical-parts/body/korpus-na-din-reiku
# https://t.me/DIY_PLC
