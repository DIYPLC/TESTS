/*
 ***************************************************************************************************************
 ***************************************************************************************************************
 ***************************************************************************************************************

 File:		  	   tcpServerRAW.c
 Modified By:     ControllersTech.com
 Updated:    	   26-Jul-2021

 ***************************************************************************************************************
 Copyright (C) 2017 ControllersTech.com

 This is a free software under the GNU license, you can redistribute it and/or modify it under the terms
 of the GNU General Public License version 3 as published by the Free Software Foundation.
 This software library is shared with public for educational purposes, without WARRANTY and Author is not liable for any damages caused directly
 or indirectly by this software, read more about this on the GNU General Public License.

 ***************************************************************************************************************
 */

/* This file was modified by ST */

#include "tcpserverRAW.h"

#include "lwip/tcp.h"
#include <string.h>

/*  protocol states */
enum tcp_server_states {
	ES_NONE = 0, ES_ACCEPTED, ES_RECEIVED, ES_CLOSING
};

/* structure for maintaining connection infos to be passed as argument
 to LwIP callbacks*/
struct tcp_server_struct {
	u8_t state; /* current connection state */
	u8_t retries;
	struct tcp_pcb *pcb; /* pointer on the current tcp_pcb */
	struct pbuf *p; /* pointer on the received/to be transmitted pbuf */
};

static err_t tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err);
static err_t tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p,
		err_t err);
static void tcp_server_error(void *arg, err_t err);
static err_t tcp_server_poll(void *arg, struct tcp_pcb *tpcb);
static err_t tcp_server_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
static void tcp_server_send(struct tcp_pcb *tpcb, struct tcp_server_struct *es);
static void tcp_server_connection_close(struct tcp_pcb *tpcb,
		struct tcp_server_struct *es);

static void tcp_server_handle(struct tcp_pcb *tpcb,
		struct tcp_server_struct *es);

/* Impementation for the TCP Server
 1. Create TCP Block.
 2. Bind the Block to server address, and port.
 3. Listen for the  incoming requests by the client
 4. Accept the Request, and now the server is ready for the data transfer
 */

void tcp_server_init(void) {
	/* 1. create new tcp pcb */
	struct tcp_pcb *tpcb;

	tpcb = tcp_new();

	err_t err;

	/* 2. bind _pcb to port 7 ( protocol) */
	ip_addr_t myIPADDR;
	IP_ADDR4(&myIPADDR, 0, 0, 0, 0); // IP = 0.0.0.0 GOTO LWIP CONFIG
	err = tcp_bind(tpcb, &myIPADDR, 502);

	if (err == ERR_OK) {
		/* 3. start tcp listening for _pcb */
		tpcb = tcp_listen(tpcb);

		/* 4. initialize LwIP tcp_accept callback function */
		tcp_accept(tpcb, tcp_server_accept);
	} else {
		/* deallocate the pcb */
		memp_free(MEMP_TCP_PCB, tpcb);
	}
}

/**
 * @brief  This function is the implementation of tcp_accept LwIP callback
 * @param  arg: not used
 * @param  newpcb: pointer on tcp_pcb struct for the newly created tcp connection
 * @param  err: not used
 * @retval err_t: error status
 */
static err_t tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err) {
	err_t ret_err;
	struct tcp_server_struct *es;

	LWIP_UNUSED_ARG(arg);
	LWIP_UNUSED_ARG(err);

	/* set priority for the newly accepted tcp connection newpcb */
	tcp_setprio(newpcb, TCP_PRIO_MIN);

	/* allocate structure es to maintain tcp connection information */
	es = (struct tcp_server_struct*) mem_malloc(
			sizeof(struct tcp_server_struct));
	if (es != NULL) {
		es->state = ES_ACCEPTED;
		es->pcb = newpcb;
		es->retries = 0;
		es->p = NULL;

		/* pass newly allocated es structure as argument to newpcb */
		tcp_arg(newpcb, es);

		/* initialize lwip tcp_recv callback function for newpcb  */
		tcp_recv(newpcb, tcp_server_recv);

		/* initialize lwip tcp_err callback function for newpcb  */
		tcp_err(newpcb, tcp_server_error);

		/* initialize lwip tcp_poll callback function for newpcb */
		tcp_poll(newpcb, tcp_server_poll, 0);

		ret_err = ERR_OK;
	} else {
		/*  close tcp connection */
		tcp_server_connection_close(newpcb, es);
		/* return memory error */
		ret_err = ERR_MEM;
	}
	return ret_err;
}

/**
 * @brief  This function is the implementation for tcp_recv LwIP callback
 * @param  arg: pointer on a argument for the tcp_pcb connection
 * @param  tpcb: pointer on the tcp_pcb connection
 * @param  pbuf: pointer on the received pbuf
 * @param  err: error information regarding the reveived pbuf
 * @retval err_t: error code
 */
static err_t tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p,
		err_t err) {
	struct tcp_server_struct *es;
	err_t ret_err;

	LWIP_ASSERT("arg != NULL", arg != NULL);

	es = (struct tcp_server_struct*) arg;

	/* if we receive an empty tcp frame from client => close connection */
	if (p == NULL) {
		/* remote host closed connection */
		es->state = ES_CLOSING;
		if (es->p == NULL) {
			/* we're done sending, close connection */
			tcp_server_connection_close(tpcb, es);
		} else {
			/* we're not done yet */
			/* acknowledge received packet */
			tcp_sent(tpcb, tcp_server_sent);

			/* send remaining data*/
			tcp_server_send(tpcb, es);
		}
		ret_err = ERR_OK;
	}
	/* else : a non empty frame was received from client but for some reason err != ERR_OK */
	else if (err != ERR_OK) {
		/* free received pbuf*/
		if (p != NULL) {
			es->p = NULL;
			pbuf_free(p);
		}
		ret_err = err;
	} else if (es->state == ES_ACCEPTED) {
		/* first data chunk in p->payload */
		es->state = ES_RECEIVED;

		/* store reference to incoming pbuf (chain) */
		es->p = p;

		/* initialize LwIP tcp_sent callback function */
		tcp_sent(tpcb, tcp_server_sent);

		/* handle the received data */
		tcp_server_handle(tpcb, es);

		ret_err = ERR_OK;
	} else if (es->state == ES_RECEIVED) {
		/* more data received from client and previous data has been already sent*/
		if (es->p == NULL) {
			es->p = p;

			/* handle the received data */
			tcp_server_handle(tpcb, es);
		} else {
			struct pbuf *ptr;

			/* chain pbufs to the end of what we recv'ed previously  */
			ptr = es->p;
			pbuf_chain(ptr, p);
		}
		ret_err = ERR_OK;
	} else if (es->state == ES_CLOSING) {
		/* odd case, remote side closing twice, trash data */
		tcp_recved(tpcb, p->tot_len);
		es->p = NULL;
		pbuf_free(p);
		ret_err = ERR_OK;
	} else {
		/* unknown es->state, trash data  */
		tcp_recved(tpcb, p->tot_len);
		es->p = NULL;
		pbuf_free(p);
		ret_err = ERR_OK;
	}
	return ret_err;
}

/**
 * @brief  This function implements the tcp_err callback function (called
 *         when a fatal tcp_connection error occurs.
 * @param  arg: pointer on argument parameter
 * @param  err: not used
 * @retval None
 */
static void tcp_server_error(void *arg, err_t err) {
	struct tcp_server_struct *es;

	LWIP_UNUSED_ARG(err);

	es = (struct tcp_server_struct*) arg;
	if (es != NULL) {
		/*  free es structure */
		mem_free(es);
	}
}

/**
 * @brief  This function implements the tcp_poll LwIP callback function
 * @param  arg: pointer on argument passed to callback
 * @param  tpcb: pointer on the tcp_pcb for the current tcp connection
 * @retval err_t: error code
 */
static err_t tcp_server_poll(void *arg, struct tcp_pcb *tpcb) {
	err_t ret_err;
	struct tcp_server_struct *es;

	es = (struct tcp_server_struct*) arg;
	if (es != NULL) {
		if (es->p != NULL) {
			tcp_sent(tpcb, tcp_server_sent);
			/* there is a remaining pbuf (chain) , try to send data */
			tcp_server_send(tpcb, es);
		} else {
			/* no remaining pbuf (chain)  */
			if (es->state == ES_CLOSING) {
				/*  close tcp connection */
				tcp_server_connection_close(tpcb, es);
			}
		}
		ret_err = ERR_OK;
	} else {
		/* nothing to be done */
		tcp_abort(tpcb);
		ret_err = ERR_ABRT;
	}
	return ret_err;
}

/**
 * @brief  This function implements the tcp_sent LwIP callback (called when ACK
 *         is received from remote host for sent data)
 * @param  None
 * @retval None
 */
static err_t tcp_server_sent(void *arg, struct tcp_pcb *tpcb, u16_t len) {
	struct tcp_server_struct *es;

	LWIP_UNUSED_ARG(len);

	es = (struct tcp_server_struct*) arg;
	es->retries = 0;

	if (es->p != NULL) {
		/* still got pbufs to send */
		tcp_sent(tpcb, tcp_server_sent);
		tcp_server_send(tpcb, es);
	} else {
		/* if no more data to send and client closed connection*/
		if (es->state == ES_CLOSING)
			tcp_server_connection_close(tpcb, es);
	}
	return ERR_OK;
}

/**
 * @brief  This function is used to send data for tcp connection
 * @param  tpcb: pointer on the tcp_pcb connection
 * @param  es: pointer on _state structure
 * @retval None
 */
static void tcp_server_send(struct tcp_pcb *tpcb, struct tcp_server_struct *es) {
	struct pbuf *ptr;
	err_t wr_err = ERR_OK;

	while ((wr_err == ERR_OK) && (es->p != NULL)
			&& (es->p->len <= tcp_sndbuf(tpcb))) {

		/* get pointer on pbuf from es structure */
		ptr = es->p;

		/* enqueue data for transmission */
		wr_err = tcp_write(tpcb, ptr->payload, ptr->len, 1);

		if (wr_err == ERR_OK) {
			u16_t plen;
			u8_t freed;

			plen = ptr->len;

			/* continue with next pbuf in chain (if any) */
			es->p = ptr->next;

			if (es->p != NULL) {
				/* increment reference count for es->p */
				pbuf_ref(es->p);
			}

			/* chop first pbuf from chain */
			do {
				/* try hard to free pbuf */
				freed = pbuf_free(ptr);
			} while (freed == 0);
			/* we can read more data now */
			tcp_recved(tpcb, plen);
		} else if (wr_err == ERR_MEM) {
			/* we are low on memory, try later / harder, defer to poll */
			es->p = ptr;
		} else {
			/* other problem ?? */
		}
	}
}

/**
 * @brief  This functions closes the tcp connection
 * @param  tcp_pcb: pointer on the tcp connection
 * @param  es: pointer on _state structure
 * @retval None
 */
static void tcp_server_connection_close(struct tcp_pcb *tpcb,
		struct tcp_server_struct *es) {

	/* remove all callbacks */
	tcp_arg(tpcb, NULL);
	tcp_sent(tpcb, NULL);
	tcp_recv(tpcb, NULL);
	tcp_err(tpcb, NULL);
	tcp_poll(tpcb, NULL, 0);

	/* delete es structure */
	if (es != NULL) {
		mem_free(es);
	}

	/* close tcp connection */
	tcp_close(tpcb);
}

/* Handle the incoming TCP Data */

/*
 *
 * https://youtu.be/olYTNjM2kwE?si=ZYmUjm2ZgOMU8tEJ
 * https://controllerstech.com/stm32-ethernet-4-tcp-server/
 * https://github.com/controllerstech/STM32-HAL/blob/master/ethernet-lwip/tcp-server/CM7/Core/Src/tcpServerRAW.c
 * http://pro-interes.com/wp-content/uploads/2020/02/LwIP_TCP_IP_stack_descriptionRus.pdf
 *
 */

static void tcp_server_handle(struct tcp_pcb *tpcb,
		struct tcp_server_struct *es) {
	struct tcp_server_struct *esTx;

	/* Get the remote IP and port */
	ip4_addr_t inIP = tpcb->remote_ip;
	uint16_t inPort = tpcb->remote_port;
	char *remIP = ipaddr_ntoa(&inIP);

	/* Allocate memory for the transmit structure */
	esTx = (struct tcp_server_struct*) mem_malloc(
			sizeof(struct tcp_server_struct));

	if (esTx != NULL) {
		esTx->state = es->state;
		esTx->pcb = es->pcb;
		esTx->p = es->p;

		static char buf[100];
		memcpy(buf, (char*) es->p->payload, es->p->len);
		size_t rx_len = es->p->len;
		unsigned char rx0 = ((unsigned char*) es->p->payload)[0];
		unsigned char rx1 = ((unsigned char*) es->p->payload)[1];
		asm("nop");
		buf[0] = 0x00; // MODBUS_TCP_MBAP_TRANSACTION_ID_HI_BYTE
		buf[1] = 0x01; // MODBUS_TCP_MBAP_TRANSACTION_ID_LO_BYTE
		buf[2] = 0x00; // MODBUS_TCP_MBAP_PROTOCOL_ID_HI_BYTE
		buf[3] = 0x00; // MODBUS_TCP_MBAP_PROTOCOL_ID_LO_BYTE
		buf[4] = 0x00; // MODBUS_TCP_MBAP_MSG_LEN_HI_BYTE
		buf[5] = 0x05; // MODBUS_TCP_MBAP_MSG_LEN_LO_BYTE
		buf[6] = 0x01; // MODBUS_TCP_MBAP_SLAVE_ADR
		buf[7] = 0x03; // MODBUS_TCP_PDU_FUN_CODE
		buf[8] = 0x02; // MODBUS_TCP_PDU_BYTE_COUNT
		buf[9] = 0x00; // MODBUS_TCP_PDU_REG_VALUE_HI_BYTE
		buf[10] = 0x07; // MODBUS_TCP_PDU_REG_VALUE_LO_BYTE
		int len = 11;
		//memset(buf, '\0', 100);
		//memcpy(buf, (char *)es->p->payload, es->p->len);
		//strcat(buf, " + Hello from TCP SERVER\n");
		esTx->p->payload = (void*) buf;
		esTx->p->tot_len = len;
		esTx->p->len = len;

		tcp_server_send(tpcb, esTx);

		pbuf_free(es->p);
		mem_free(esTx);
	}
}
