/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "lwip.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#include <stdint.h>
#include <stdbool.h>
#include <iso646.h>

#include "GlobalVar.h"
#include "FbTs.h"
#include "FbBlink.h"

#define SetBit(Var,Bit)   ( Var = Var |  (1 << (Bit)) )
#define ResetBit(Var,Bit) ( Var = Var & ~(1 << (Bit)) )

#define LED1_OFF() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, GPIO_PIN_SET)
#define LED2_OFF() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_SET)
#define LED3_OFF() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_SET)
#define LED1_ON() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, GPIO_PIN_RESET)
#define LED2_ON() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_RESET)
#define LED3_ON() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_RESET)
#define SW1_STATE_ON() (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10) == GPIO_PIN_RESET)
#define SW2_STATE_ON() (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_11) == GPIO_PIN_RESET)
#define SW3_STATE_ON() (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12) == GPIO_PIN_RESET)

#define millis() HAL_GetTick() //Arduino function.

static struct GlobalVar GV = { 0 };
static struct DbTs DbTs1 = { 0 };
static struct DbBlink DbBlink1 = { 0 };

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

void udp_receive_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p,
		const ip_addr_t *addr, u16_t port) {
	struct pbuf *txBuf;
	/* Convert client IP to readable string */
	char *remoteIP = ipaddr_ntoa(addr);
	/* Build the response string */
	char buf[100];
	// int len = sprintf(buf, "Hello %s From UDP SERVER\n", (char*) p->payload);
	buf[0] = 0x00; // MODBUS_TCP_MBAP_TRANSACTION_ID_HI_BYTE
	buf[1] = 0x01; // MODBUS_TCP_MBAP_TRANSACTION_ID_LO_BYTE
	buf[2] = 0x00; // MODBUS_TCP_MBAP_PROTOCOL_ID_HI_BYTE
	buf[3] = 0x00; // MODBUS_TCP_MBAP_PROTOCOL_ID_LO_BYTE
	buf[4] = 0x00; // MODBUS_TCP_MBAP_MSG_LEN_HI_BYTE
	buf[5] = 0x05; // MODBUS_TCP_MBAP_MSG_LEN_LO_BYTE
	buf[6] = 0x01; // MODBUS_TCP_MBAP_SLAVE_ADR
	buf[7] = 0x03; // MODBUS_TCP_PDU_FUN_CODE
	buf[8] = 0x02; // MODBUS_TCP_PDU_BYTE_COUNT
	buf[9] = 0x00; // MODBUS_TCP_PDU_REG_VALUE_HI_BYTE
	buf[10] = 0x07; // MODBUS_TCP_PDU_REG_VALUE_LO_BYTE
	int len = 11;
	/* Allocate transmit pbuf */
	txBuf = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_RAM);
	/* Copy response into pbuf */
	pbuf_take(txBuf, buf, len);
	/* Connect to the client and send */
	udp_connect(upcb, addr, port);
	udp_send(upcb, txBuf);
	/* Disconnect to allow new clients */
	udp_disconnect(upcb);
	/* Free both buffers */
	pbuf_free(txBuf);
	pbuf_free(p);
}

/*
 *
 * https://youtu.be/l193dYefUE8?si=3rDBFiK_ZvTdWRRa
 * https://controllerstech.com/stm32-ethenret-2-udp-server/
 * https://github.com/controllerstech/STM32-HAL/blob/master/ethernet-lwip/udp-server/CM7/Core/Src/udpServerRAW.c
 * http://pro-interes.com/wp-content/uploads/2020/02/LwIP_TCP_IP_stack_descriptionRus.pdf
 *
 */

void udpServer_init(void) {
	struct udp_pcb *upcb;
	err_t err;
	upcb = udp_new();
	ip_addr_t myIPADDR;
	IP_ADDR4(&myIPADDR, 0, 0, 0, 0); // IP = 0.0.0.0 GOTO LWIP CONFIG
	err = udp_bind(upcb, &myIPADDR, 502);  // UDP Port = 502
	if (err == ERR_OK) {
		udp_recv(upcb, udp_receive_callback, NULL);
	} else {
		udp_remove(upcb);
	}
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	LED1_OFF();
	LED2_OFF();
	LED3_OFF();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LWIP_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

	udpServer_init();   // Start the UDP server

	GV.Reset = true;
	//Расчет времени скана.
	//             DbTs
	//    +---------------------+
	//    |        FbTs         |
	//   -|millis          Ts_ms|->-
	//   -|Reset              Ts|->-
	//    |            Ts_ms_max|->-
	//    |             Uptime_s|->-
	//    +---------------------+
	DbTs1.millis = millis(); //millis() Arduino.
	DbTs1.Reset = GV.Reset; //Сброс при перезагрузке.
	FbTs(&DbTs1); //Расчет времени скана.
	GV.Ts_ms = DbTs1.Ts_ms; //Шаг дискретизации по времени [мс].
	GV.Ts = DbTs1.Ts; //Шаг дискретизации по времени [с].
	GV.Ts_ms_max = DbTs1.Ts_ms_max; //Максимальное время скана [мс].
	GV.Uptime_s = DbTs1.Uptime_s; //Время в работе [мс].

	while (1) {

		GV.Reset = false;
		//Расчет времени скана.
		//             DbTs
		//    +---------------------+
		//    |        FbTs         |
		//   -|millis          Ts_ms|->-
		//   -|Reset              Ts|->-
		//    |            Ts_ms_max|->-
		//    |             Uptime_s|->-
		//    +---------------------+
		DbTs1.millis = millis();	//millis() Arduino.
		DbTs1.Reset = GV.Reset;	//Сброс при перезагрузке.
		FbTs(&DbTs1);	//Расчет времени скана.
		GV.Ts_ms = DbTs1.Ts_ms;	//Шаг дискретизации по времени [мс].
		GV.Ts = DbTs1.Ts;	//Шаг дискретизации по времени [с].
		GV.Ts_ms_max = DbTs1.Ts_ms_max;	//Максимальное время скана [мс].
		GV.Uptime_s = DbTs1.Uptime_s;	//Время в работе [мс].

		MX_LWIP_Process(); // HAL_Delay() далее запрещен вроде как не блокирует.

		//Пример работы с дискретными алгоритмами.
		//Мигалка.
		//            DbBlink
		//    +---------------------+
		//    |       FbBlink       |
		//   -|Time_on_ms        Out|->-
		//   -|Time_off_ms          |
		//   -|Ts_ms                |
		//   -|Reset                |
		//    +---------------------+
		DbBlink1.Time_on_ms = 500;	//Время импульса [мс].
		DbBlink1.Time_off_ms = 500;	//Время паузы [мс].
		DbBlink1.Ts_ms = GV.Ts_ms;	//Шаг дискретизации по времени [мс].
		DbBlink1.Reset = GV.Reset;	//Сброс при перезагрузке.
		FbBlink(&DbBlink1);	//Мигалка.

		if (DbBlink1.Out) {
			LED1_ON();
		} else {
			LED1_OFF();
		}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE10 PE11 PE12 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PE13 PE14 PE15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
