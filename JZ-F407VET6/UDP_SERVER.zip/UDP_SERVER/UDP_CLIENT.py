#!/usr/bin/python3
# -*- coding: utf-8 -*-

import socket
import struct
import time

def modbus_udp_client_read_holding_register_uint16(ip_address='192.168.13.127', upd_port=502,
                                                   modbus_address=1, register_address=0) -> int:
    """ MODBUS UDP MASTER READ REGISTER FROM PLC """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client_socket:
            timeout_seconds = 1.0
            client_socket.settimeout(timeout_seconds)
            tx_transaction_id = 1
            tx_protocol_id = 0
            tx_message_length = 6
            tx_modbus_address = modbus_address
            tx_modbus_function = 3
            tx_register_address = register_address
            tx_register_count = 1
            tx_adu = struct.pack(">HHHBBHH", tx_transaction_id, tx_protocol_id, tx_message_length,
                                 tx_modbus_address, tx_modbus_function, tx_register_address, tx_register_count)
            print("tx_adu", tx_adu)
            client_socket.sendto(tx_adu, (ip_address, upd_port))
            #time.sleep(2.0)
            buffer_size = 1024
            rx_adu, address = client_socket.recvfrom(buffer_size)
            print("rx_adu", rx_adu)
            (rx_transaction_id, rx_protocol_id, rx_message_length, rx_modbus_address, rx_modbus_function,
             rx_byte_count, rx_register_value) = struct.unpack(">HHHBBBH", rx_adu)
        return rx_register_value
    except BaseException as er_modbus_udp_client_read_holding_register_uint16:
        print("[ERROR] modbus_udp_client_read_holding_register_uint16()",
              er_modbus_udp_client_read_holding_register_uint16)
        return 0


def __unit_test__():
    while True:
        time.sleep(1.0)
        mw0 = modbus_udp_client_read_holding_register_uint16(register_address=0)
        print("[OK] receive mw0 = ", mw0)
    input("press any key for exit...")
    return


if __name__ == "__main__":
    __unit_test__()

# @COPYLEFT ALL WRONGS RESERVED :)
# Author: VA
# Contacts: DIY.PLC.314@gmail.com
# Date start LIB_PLC: 2014
# License: GNU GPL-2.0-or-later
# https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# https://www.youtube.com/watch?v=n1F_MfLRlX0
# https://www.youtube.com/@DIY_PLC
# https://github.com/DIYPLC/LIB_PLC
# https://oshwlab.com/diy.plc.314/PLC_HW1_SW1
# https://3dtoday.ru/3d-models/mechanical-parts/body/korpus-na-din-reiku
# https://t.me/DIY_PLC
